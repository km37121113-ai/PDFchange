import React, { useState, useCallback } from 'react';
import { DropZone } from './components/DropZone';
import { SlidePreview } from './components/SlidePreview';
import { loadPdf, renderPageToImage } from './services/pdfUtils';
import { analyzeSlideImage } from './services/geminiUtils';
import { generatePptx } from './services/pptxUtils';
import { ProcessingStatus, SlideData } from './types';
import { Loader2, Download, CheckCircle2, AlertCircle, FileType } from 'lucide-react';

export default function App() {
  const [status, setStatus] = useState<ProcessingStatus>(ProcessingStatus.IDLE);
  const [slides, setSlides] = useState<SlideData[]>([]);
  const [progress, setProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleProcess = useCallback(async (file: File) => {
    try {
      setErrorMsg(null);
      setStatus(ProcessingStatus.READING_PDF);
      setSlides([]);

      const pdf = await loadPdf(file);
      const totalPages = pdf.numPages;
      setProgress({ current: 0, total: totalPages });

      setStatus(ProcessingStatus.ANALYZING_PAGES);
      const processedSlides: SlideData[] = [];

      // Process pages sequentially to show progress
      for (let i = 1; i <= totalPages; i++) {
        setProgress(prev => ({ ...prev, current: i }));
        
        // 1. Render Page
        const imageBase64 = await renderPageToImage(pdf, i);
        
        // 2. Analyze with Gemini
        // We use the index i-1 for the ID
        const slideData = await analyzeSlideImage(imageBase64, i - 1);
        processedSlides.push(slideData);
        
        // Update state to show live preview
        setSlides(prev => [...prev, slideData]);
      }

      setStatus(ProcessingStatus.COMPLETED);

    } catch (err: any) {
      console.error(err);
      setStatus(ProcessingStatus.ERROR);
      setErrorMsg(err.message || "PDFの処理中に予期せぬエラーが発生しました。");
    }
  }, []);

  const handleDownload = async () => {
    if (slides.length === 0) return;
    setStatus(ProcessingStatus.GENERATING_PPTX);
    try {
      await generatePptx(slides);
      setStatus(ProcessingStatus.COMPLETED);
    } catch (e) {
      console.error(e);
      alert("PPTXファイルの生成に失敗しました");
      setStatus(ProcessingStatus.COMPLETED);
    }
  };

  const handleReset = () => {
    setStatus(ProcessingStatus.IDLE);
    setSlides([]);
    setErrorMsg(null);
    setProgress({ current: 0, total: 0 });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-indigo-50/30 text-slate-800">
      <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-200">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-indigo-600 p-2 rounded-lg">
               <FileType className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-indigo-700 to-indigo-500">
              PDF to PPTX <span className="font-light text-slate-400">AI 変換</span>
            </h1>
          </div>
          {status === ProcessingStatus.COMPLETED && (
            <button 
              onClick={handleReset}
              className="text-sm text-gray-500 hover:text-indigo-600 transition-colors"
            >
              最初に戻る
            </button>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        
        {/* Intro / Upload Section */}
        {status === ProcessingStatus.IDLE && (
          <div className="max-w-2xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="text-center space-y-4">
              <h2 className="text-4xl font-extrabold text-slate-900 tracking-tight">
                PDFを瞬時に編集可能なスライドへ変換
              </h2>
              <p className="text-lg text-slate-600 max-w-lg mx-auto">
                高度なAIを使用してテキストと画像を分離し、箇条書きを構造化して、PowerPointファイルを生成します。
              </p>
            </div>
            
            <div className="bg-white p-2 rounded-2xl shadow-xl shadow-indigo-100/50">
              <DropZone onFileSelect={handleProcess} />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
               {[
                 { title: "スマートテキスト抽出", desc: "視覚情報を編集可能なテキストに変換" },
                 { title: "画像の分離", desc: "複雑な図表は参照用画像として保持" },
                 { title: "スピーカーノート", desc: "発表用のメモをAIが自動生成" }
               ].map((feat, i) => (
                 <div key={i} className="bg-white/50 border border-white p-4 rounded-xl shadow-sm">
                   <h3 className="font-semibold text-slate-800">{feat.title}</h3>
                   <p className="text-sm text-slate-500 mt-1">{feat.desc}</p>
                 </div>
               ))}
            </div>
          </div>
        )}

        {/* Processing / Progress Section */}
        {(status === ProcessingStatus.READING_PDF || status === ProcessingStatus.ANALYZING_PAGES) && (
          <div className="max-w-2xl mx-auto text-center space-y-8">
             <div className="flex flex-col items-center justify-center p-12 bg-white rounded-2xl shadow-lg border border-indigo-50">
                <Loader2 className="w-12 h-12 text-indigo-600 animate-spin mb-4" />
                <h3 className="text-xl font-semibold text-slate-900">
                  ドキュメントを分析中...
                </h3>
                <p className="text-slate-500 mt-2">
                  スライド {progress.current} / {progress.total} を処理中
                </p>
                
                <div className="w-full max-w-md bg-gray-100 rounded-full h-2.5 mt-6 overflow-hidden">
                  <div 
                    className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300 ease-out" 
                    style={{ width: `${(progress.current / (progress.total || 1)) * 100}%` }}
                  />
                </div>
                
                <p className="text-xs text-gray-400 mt-4 max-w-xs">
                  AIがレイアウトを読み取り、編集可能なコンテンツを抽出しています。
                </p>
             </div>
          </div>
        )}

        {/* Error State */}
        {status === ProcessingStatus.ERROR && (
          <div className="max-w-xl mx-auto text-center p-8 bg-white rounded-2xl shadow-lg border border-red-100">
            <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-lg font-semibold text-red-900">処理に失敗しました</h3>
            <p className="text-red-600 mt-2 mb-6">{errorMsg}</p>
            <button
              onClick={handleReset}
              className="px-6 py-2 bg-slate-900 text-white rounded-lg hover:bg-slate-800 transition-colors"
            >
              再試行
            </button>
          </div>
        )}

        {/* Results Section */}
        {(status === ProcessingStatus.COMPLETED || slides.length > 0) && status !== ProcessingStatus.READING_PDF && status !== ProcessingStatus.IDLE && (
          <div className="space-y-8 animate-in fade-in duration-500">
            
            <div className="flex flex-col md:flex-row items-center justify-between gap-4 bg-indigo-900 text-white p-6 rounded-2xl shadow-xl">
              <div>
                <h2 className="text-2xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-green-400" />
                  変換完了
                </h2>
                <p className="text-indigo-200 mt-1">
                  {slides.length} 枚のスライドを分析しました。以下で内容を確認するか、今すぐダウンロードしてください。
                </p>
              </div>
              <button
                onClick={handleDownload}
                disabled={status === ProcessingStatus.GENERATING_PPTX}
                className="group flex items-center gap-2 bg-white text-indigo-900 px-8 py-3 rounded-xl font-bold hover:bg-indigo-50 transition-all disabled:opacity-70 shadow-lg shadow-indigo-900/20"
              >
                {status === ProcessingStatus.GENERATING_PPTX ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Download className="w-5 h-5 group-hover:scale-110 transition-transform" />
                )}
                PowerPointをダウンロード
              </button>
            </div>

            <div className="grid grid-cols-1 gap-6">
              {slides.map((slide) => (
                <SlidePreview key={slide.id} slide={slide} />
              ))}
            </div>

            {/* Bottom Download (Sticky for Mobile) */}
             <div className="fixed bottom-6 left-0 right-0 px-4 md:hidden pointer-events-none">
                <button
                onClick={handleDownload}
                 disabled={status === ProcessingStatus.GENERATING_PPTX}
                className="pointer-events-auto w-full flex items-center justify-center gap-2 bg-indigo-600 text-white px-6 py-4 rounded-xl font-bold shadow-2xl"
              >
                <Download className="w-5 h-5" /> PPTXをダウンロード
              </button>
             </div>
          </div>
        )}
      </main>
    </div>
  );
}