export interface SlideData {
  id: number;
  originalImage: string; // Base64 of the PDF page
  title: string;
  content: string[];
  speakerNotes: string;
  hasImages: boolean;
  imageDescription?: string;
}

export enum ProcessingStatus {
  IDLE = 'IDLE',
  READING_PDF = 'READING_PDF',
  ANALYZING_PAGES = 'ANALYZING_PAGES',
  GENERATING_PPTX = 'GENERATING_PPTX',
  COMPLETED = 'COMPLETED',
  ERROR = 'ERROR'
}
