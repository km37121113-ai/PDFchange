import PptxGenJS from "pptxgenjs";
import { SlideData } from "../types";

export const generatePptx = async (slidesData: SlideData[]) => {
  const pptx = new PptxGenJS();

  // Set Metadata
  pptx.author = "AI変換ツール";
  pptx.company = "Gemini Powered";
  pptx.title = "変換されたプレゼンテーション";

  // Define a master slide template (simple)
  pptx.defineSlideMaster({
    title: "MASTER_SLIDE",
    background: { color: "FFFFFF" },
    objects: [
      { rect: { x: 0, y: 0, w: "100%", h: 0.75, fill: "4F46E5" } }, // Header bar
    ],
  });

  slidesData.forEach((data) => {
    const slide = pptx.addSlide();
    
    // Add original image as a reference on the left (small) or background? 
    // Let's make it a reference image on the right side if there are images, or just helpful context.
    // For "Editability", we focus on the text, but users requested image separation.
    // Since we can't easily extract the isolated image object, we place the full screenshot 
    // cropped or scaled as a reference if the AI detected complex visuals.
    
    // 1. Slide Title
    slide.addText(data.title, {
      x: 0.5,
      y: 0.3,
      w: "90%",
      h: 0.6,
      fontSize: 24,
      bold: true,
      color: "FFFFFF", // On the blue header
    });

    // 2. Content (Bullet points)
    // If the slide has images, we split layout: Text Left, Visual Reference Right
    const textWidth = data.hasImages ? "50%" : "90%";
    
    slide.addText(data.content.map(c => ({ text: c, options: { breakLine: true } })), {
      x: 0.5,
      y: 1.2,
      w: textWidth,
      h: "70%",
      fontSize: 16,
      color: "363636",
      bullet: true,
      valign: "top"
    });

    // 3. Visual Reference (if deemed necessary or requested)
    // We add the original screenshot to the right side if there are images detected
    if (data.hasImages) {
      slide.addImage({
        data: data.originalImage,
        x: "55%",
        y: 1.2,
        w: "40%",
        h: 3.5,
        sizing: { type: "contain", w: "40%", h: 3.5 }
      });
      
      // Add a caption for the image
      if (data.imageDescription) {
        slide.addText(`[画像の概要: ${data.imageDescription}]`, {
           x: "55%",
           y: 4.8,
           w: "40%",
           h: 0.5,
           fontSize: 10,
           color: "888888",
           italic: true
        });
      }
    }

    // 4. Speaker Notes
    if (data.speakerNotes) {
      slide.addNotes(data.speakerNotes);
    }
  });

  await pptx.writeFile({ fileName: `Converted-Presentation-${Date.now()}.pptx` });
};