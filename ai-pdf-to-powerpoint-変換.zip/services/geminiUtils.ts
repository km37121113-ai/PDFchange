import { GoogleGenAI, Type } from "@google/genai";
import { SlideData } from "../types";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to remove data:image/jpeg;base64, prefix
const cleanBase64 = (dataUrl: string) => dataUrl.split(',')[1];

export const analyzeSlideImage = async (base64Image: string, pageIndex: number): Promise<SlideData> => {
  if (!apiKey) {
    throw new Error("APIキーが見つかりません。環境設定を確認してください。");
  }

  const prompt = `
    このプレゼンテーションスライドの画像を分析し、PowerPointプレゼンテーション用の構造化データを抽出してください。
    
    ルール:
    1. メインの「タイトル」を抽出してください。
    2. 箇条書きや本文テキストを文字列のリストとして抽出してください。
    3. スライドの重要なメッセージを要約した簡潔な「スピーカーノート（発表者用メモ）」を生成してください。
    4. スライドに重要な図表、グラフ、写真（ロゴや背景を除く）が含まれているか検出し、含まれている場合は 'hasImages' を true に設定してください。
    5. 画像が含まれている場合、それが何を表しているか短い説明文（imageDescription）を提供してください。
    
    出力言語: 全てのテキスト（タイトル、内容、ノート、説明）は日本語で出力してください。元のテキストが外国語の場合は、自然な日本語に翻訳してください。
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-latest",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64(base64Image)
            }
          },
          { text: prompt }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.ARRAY, items: { type: Type.STRING } },
            speakerNotes: { type: Type.STRING },
            hasImages: { type: Type.BOOLEAN },
            imageDescription: { type: Type.STRING }
          },
          required: ["title", "content", "speakerNotes", "hasImages"]
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("AIからの応答が空でした。");

    const data = JSON.parse(text);

    return {
      id: pageIndex,
      originalImage: base64Image,
      title: data.title || `スライド ${pageIndex + 1}`,
      content: data.content || [],
      speakerNotes: data.speakerNotes || "",
      hasImages: data.hasImages || false,
      imageDescription: data.imageDescription || ""
    };
  } catch (error) {
    console.error("Error analyzing slide:", error);
    // Fallback in case of AI failure
    return {
      id: pageIndex,
      originalImage: base64Image,
      title: `スライド ${pageIndex + 1} (分析失敗)`,
      content: ["AIによるコンテンツ抽出に失敗しました。"],
      speakerNotes: "",
      hasImages: true
    };
  }
};