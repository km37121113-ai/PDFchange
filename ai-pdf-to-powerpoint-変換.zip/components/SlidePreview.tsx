import React from 'react';
import { SlideData } from '../types';
import { Layout, Image as ImageIcon, FileText } from 'lucide-react';

interface SlidePreviewProps {
  slide: SlideData;
}

export const SlidePreview: React.FC<SlidePreviewProps> = ({ slide }) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex flex-col md:flex-row h-full">
      {/* Visual Reference */}
      <div className="md:w-1/3 bg-gray-100 relative group min-h-[200px]">
        <img 
          src={slide.originalImage} 
          alt={`Original Slide ${slide.id + 1}`} 
          className="w-full h-full object-contain p-2"
        />
        <div className="absolute top-2 left-2 bg-black/60 text-white text-xs px-2 py-1 rounded backdrop-blur-sm">
          元のPDF
        </div>
      </div>

      {/* Extracted Editable Content */}
      <div className="md:w-2/3 p-6 flex flex-col space-y-4">
        <div>
          <h4 className="text-xs font-semibold text-indigo-600 uppercase tracking-wide mb-1 flex items-center gap-1">
            <Layout className="w-3 h-3" /> 抽出された構成
          </h4>
          <h3 className="text-lg font-bold text-gray-900 leading-tight">
            {slide.title}
          </h3>
        </div>

        <div className="flex-1">
          <ul className="space-y-2">
            {slide.content.map((point, idx) => (
              <li key={idx} className="flex items-start text-sm text-gray-600">
                <span className="mr-2 mt-1.5 w-1.5 h-1.5 bg-indigo-400 rounded-full flex-shrink-0" />
                <span>{point}</span>
              </li>
            ))}
            {slide.content.length === 0 && (
               <li className="text-sm text-gray-400 italic">テキストが検出されませんでした。</li>
            )}
          </ul>
        </div>

        {slide.hasImages && (
          <div className="bg-orange-50 rounded-md p-3 border border-orange-100">
            <div className="flex items-start gap-2">
              <ImageIcon className="w-4 h-4 text-orange-500 mt-0.5" />
              <div>
                <span className="text-xs font-semibold text-orange-700 block mb-1">画像を検出しました</span>
                <p className="text-xs text-orange-800 leading-relaxed">
                  {slide.imageDescription || "画像要素が含まれています。参照用画像としてスライドに含まれます。"}
                </p>
              </div>
            </div>
          </div>
        )}

        {slide.speakerNotes && (
           <div className="border-t border-gray-100 pt-3 mt-auto">
             <div className="flex items-center gap-2 text-xs text-gray-400 mb-1">
               <FileText className="w-3 h-3" /> スピーカーノート
             </div>
             <p className="text-xs text-gray-500 italic line-clamp-2">
               {slide.speakerNotes}
             </p>
           </div>
        )}
      </div>
    </div>
  );
};