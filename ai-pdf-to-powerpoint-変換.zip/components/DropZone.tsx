import React, { useCallback } from 'react';
import { Upload, FileText } from 'lucide-react';

interface DropZoneProps {
  onFileSelect: (file: File) => void;
  disabled?: boolean;
}

export const DropZone: React.FC<DropZoneProps> = ({ onFileSelect, disabled }) => {
  const handleDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      if (disabled) return;
      if (e.dataTransfer.files && e.dataTransfer.files[0]) {
        const file = e.dataTransfer.files[0];
        if (file.type === 'application/pdf') {
          onFileSelect(file);
        } else {
          alert('PDFファイルをアップロードしてください。');
        }
      }
    },
    [onFileSelect, disabled]
  );

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      if (disabled) return;
      if (e.target.files && e.target.files[0]) {
        onFileSelect(e.target.files[0]);
      }
    },
    [onFileSelect, disabled]
  );

  return (
    <div
      onDrop={handleDrop}
      onDragOver={(e) => e.preventDefault()}
      className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-all duration-200 
        ${disabled 
          ? 'border-gray-300 bg-gray-50 cursor-not-allowed opacity-60' 
          : 'border-indigo-300 bg-indigo-50/50 hover:bg-indigo-50 hover:border-indigo-500 cursor-pointer'
        }`}
    >
      <input
        type="file"
        accept="application/pdf"
        onChange={handleChange}
        disabled={disabled}
        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
      />
      <div className="flex flex-col items-center justify-center space-y-4">
        <div className={`p-4 rounded-full ${disabled ? 'bg-gray-200' : 'bg-white shadow-sm'}`}>
          {disabled ? (
             <FileText className="w-8 h-8 text-gray-400" />
          ) : (
             <Upload className="w-8 h-8 text-indigo-600" />
          )}
        </div>
        <div className="space-y-1">
          <p className="text-lg font-medium text-gray-900">
            {disabled ? '処理中...' : 'ここにPDFをドロップ'}
          </p>
          {!disabled && (
            <p className="text-sm text-gray-500">
              またはクリックして選択
            </p>
          )}
        </div>
      </div>
    </div>
  );
};